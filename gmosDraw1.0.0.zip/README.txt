Program: gmosDraw (Genome MOSaic structure Draw, an accessory progam for gmos)
Author: Mirjana Domazet-Loso, University of Zagreb Faculty of Electrical Engineering and Computing, Zagreb, Croatia
Documentation: gmosDrawDoc.pdf
Contact: Mirjana.Domazet-Loso@fer.hr
